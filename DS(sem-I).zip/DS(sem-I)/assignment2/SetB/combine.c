#include <stdio.h>

struct Employee {
    char name[100];
    int age;
};

void bubbleSort(struct Employee employees[], int count) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (employees[j].age > employees[j + 1].age) {
                struct Employee temp = employees[j];
                employees[j] = employees[j + 1];
                employees[j + 1] = temp;
            }
        }
    }
}

void insertionSort(struct Employee employees[], int count) {
    for (int i = 1; i < count; i++) {
        struct Employee key = employees[i];
        int j = i - 1;
        while (j >= 0 && employees[j].age > key.age) {
            employees[j + 1] = employees[j];
            j--;
        }
        employees[j + 1] = key;
    }
}

void selectionSort(struct Employee employees[], int count) {
    for (int i = 0; i < count - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < count; j++) {
            if (employees[j].age < employees[minIndex].age) {
                minIndex = j;
            }
        }
        struct Employee temp = employees[i];
        employees[i] = employees[minIndex];
        employees[minIndex] = temp;
    }
}

int main() {
    struct Employee employees[10];
    int count = 0;

    FILE *file = fopen("emp.txt", "r");
    while (fscanf(file, "%s %d", employees[count].name, &employees[count].age) == 2) {
        count++;
    }
    fclose(file);

    bubbleSort(employees, count);
    printf("Bubble Sort:\n");
    for (int i = 0; i < count; i++) {
        printf("%s %d\n", employees[i].name, employees[i].age);
    }

    insertionSort(employees, count);
    printf("Insertion Sort:\n");
    for (int i = 0; i < count; i++) {
        printf("%s %d\n", employees[i].name, employees[i].age);
    }

    selectionSort(employees, count);
    printf("Selection Sort:\n");
    for (int i = 0; i < count; i++) {
        printf("%s %d\n", employees[i].name, employees[i].age);
    }

    return 0;
}




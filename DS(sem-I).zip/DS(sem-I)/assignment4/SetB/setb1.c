#include <stdio.h>
#include <stdlib.h>


typedef struct Node {
    int data;
    struct Node* next;
} Node;


Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}


void insertOrdered(Node** head, int data) {
    Node* newNode = createNode(data);
    if (*head == NULL || (*head)->data >= data) {
       
        newNode->next = *head;
        *head = newNode;
    } else {
       
        Node* current = *head;
        while (current->next != NULL && current->next->data < data) {
            current = current->next;
        }
       
        newNode->next = current->next;
        current->next = newNode;
    }
}


int search(Node* head, int data) {
    Node* current = head;
    while (current != NULL) {
        if (current->data == data) {
            return 1; // Element found
        }
        if (current->data > data) {
            return 0; // Element not found (since list is ordered)
        }
        current = current->next;
    }
    return 0; // Element not found
}


void display(Node* head) {
    Node* current = head;
    while (current != NULL) {
        printf("%d -> ", current->data);
        current = current->next;
    }
    printf("NULL\n");
}

int main() {
    Node* head = NULL; // Initialize the head of the list

    int choice, value;
   
    do {
        printf("\n1. Insert element\n");
        printf("2. Search element\n");
        printf("3. Display list\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                insertOrdered(&head, value);
                break;
            case 2:
                printf("Enter value to search: ");
                scanf("%d", &value);
                if (search(head, value)) {
                    printf("%d is present in the list.\n", value);
                } else {
                    printf("%d is not present in the list.\n", value);
                }
                break;
            case 3:
                printf("List elements:\n");
                display(head);
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while (choice != 4);

   
    Node* current = head;
    Node* nextNode;
    while (current != NULL) {
        nextNode = current->next;
        free(current);
        current = nextNode;
    }

    return 0;
}
